﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Html;

namespace Helper.Extensions
{
    public static class MyHelpers
    {
        public enum AjaxMethods
        {
            GET,
            POST
        }
        public static MvcHtmlString AsyncPartial(this HtmlHelper helper, string controller, string action,string previewPartialName=null, AjaxMethods method = AjaxMethods.GET, TempDataDictionary TempData=null)
        {
 
            string containerIdShadow = $"div-{controller}-{action}-sh";

            string js = $"function get_{controller}_{action}()" +
                            "{" +
                                    $"var d= document.getElementById('div-{controller}-{action}'); "+
                                    $"var ds= document.getElementById('div-{controller}-{action}-sh'); "+

                                    "var x = new XMLHttpRequest();" +
                                    "x.onreadystatechange = function() {" +
                                        "  if (x.readyState == XMLHttpRequest.DONE ) {" +
                                            "  if (x.status == 200) {" +
                                                 $"d.innerHTML = x.responseText.replace(/data-partial-refresh/ig, 'data-partial-refresh onclick=\"get_{controller}_{action}()\"');" +
                                                  $"ds.style.display='none';" +
                                                  $"d.style.display='block';" +
                                            "  }" +
                                            "else if (x.status == 400) {" +
                                             "      alert('Error 400');" +
                                             "    }" +
                                             "else{" +
                                             "      alert('Generic error');" +
                                             "    }" +
                                         "  }" +
                                    "};" +
                                      $"ds.style.display='block';" +
                                      $"d.style.display='none';" +
                                    $"x.open('{method}', '/{controller}/{action}', true);" +
                                    "x.send();" +
                             "};" +
                             $"get_{controller}_{action}();";

            MvcHtmlString StringPartial = PartialExtensions.Partial(helper, previewPartialName ==null? action + "_preview":previewPartialName);

            if (TempData != null)
            {
                TempData["script"] += js;
                return MvcHtmlString.Create($"<div  id='div-{controller}-{action}'>" + StringPartial.ToString() + "</div>" +
                                       $"<div  id='div-{controller}-{action}-sh' style='display:none'>" + StringPartial.ToString() + "</div>"
                                       );
            }
            else
            {
                return MvcHtmlString.Create($"<div  id='div-{controller}-{action}'>" + StringPartial.ToString() + "</div>" +
                                      $"<div  id='div-{controller}-{action}-sh' style='display:none'>" + StringPartial.ToString() + "</div>"+
                                      "<script>"+js+"</script>");
            }
          
        }
    }
}
